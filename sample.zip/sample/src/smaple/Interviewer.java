/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package smaple;

import java.util.ArrayList;


/**
 *
 * @author zxh25
 */
public class Interviewer extends Employee {
//   private Appointment[] appointments= new Appointment[10];
    //private  ArrayList<Appointment>() appointments =new ArrayList<>(); 
//   public Interviewer(){}
//   public Interviewer(String fn,String ln,String email,String phone,Appointment[] aps){
//   super();
//   this.appointments=aps;
//   
//   }
    public void createInterview(){
    
    }
    
}
